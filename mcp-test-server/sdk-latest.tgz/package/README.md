# AMS SDK — Node.js

Node.js wrapper for the AMS License Validator SDK.

## Installation

```bash
npm install @ams/sdk
```

## Quick Start

```typescript
import { AmsClient } from "@ams/sdk";

const ams = new AmsClient({
  onTerminate: (reason) => {
    console.error(`AMS terminated container: ${reason}`);
    process.exit(1);
  },
});

await ams.start(); // blocks until handshake succeeds

// ... your application logic ...

await ams.recordExecution(); // optional: report one execution
await ams.recordMetric("imagesProcessed", 42); // optional: custom metric
```

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `AMS_API_KEY` | Yes | Consumer AMS API key |
| `AMS_SERVICE_ID` | Yes | UUID of the service being consumed |
| `AMS_LICENSE_TOKEN` | No | Signed JWT for OfflineTtl mode |
| `AMS_GATEWAY_URL` | No | APIM gateway URL (default: production) |

## Programmatic Configuration

```typescript
import { AmsClient } from "@ams/sdk";

const ams = new AmsClient({
  onTerminate: (reason) => process.exit(1),
  config: {
    apiKey: "ams_k_...",
    serviceId: "a1b2c3d4-...",
    heartbeatIntervalSeconds: 30,
  },
});
```

## Local Dev Mode

The published package ships only a **linux-x64** `ams-sdk-core` binary, so
`start()` fails on macOS/Windows. Dev mode swaps the subprocess for an
**in-process stub** so you can build and test your integration — tracking calls,
middleware, and shutdown handling — without a Linux container or a real license.
It is "Stripe test mode": real enough to build against, but it performs **no
license enforcement**.

```typescript
const ams = new AmsClient({ onTerminate: shutdown, devMode: true });
await ams.start();                          // no binary, no license needed
await ams.recordExecution({ endpoint: "/api/x" }); // accepted (no-op)

ams.simulateTerminate("license_revoked");   // exercise your shutdown handler
```

**Two-flag opt-in.** Dev mode activates only when **both** `devMode: true` is
passed in code **and** the `AMS_DEV_MODE` environment variable is truthy
(`true`/`1`/`yes`/`on`). If either is missing, the SDK runs normally against the
real core and logs a warning. This guarantees a `devMode: true` left in shipped
code cannot silently disable licensing in production.

- **Loud logging:** a banner is logged via `console.warn` whenever dev mode is active.
- **Auditable status:** `getLicenseStatus()` resolves to `"dev"` (never `"active"`).
- **`simulateTerminate(reason = "license_revoked")`:** dev-only; fires
  `onTerminate` with a stable reason string exactly as a real kill-switch would.
  Throws `AmsConfigError` if called when dev mode is not active.

> ⚠️ Never ship a production image with `AMS_DEV_MODE` set — a CI build gate in
> the image-build pipeline enforces this.

## Requirements

- Node.js >= 18.0.0
- `ams-sdk-core` binary (bundled in package)
